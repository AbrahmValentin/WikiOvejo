// Scroll suave estilo Wikipedia
document.querySelectorAll(".sidebar a").forEach(link => {
  link.addEventListener("click", function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    target.scrollIntoView({ behavior: "smooth" });
  });
});

// Buscador fake (solo estética)
document.getElementById("search").addEventListener("keyup", function(e) {
  if (e.key === "Enter") {
    alert("No se encontraron resultados para: " + this.value);
  }
});